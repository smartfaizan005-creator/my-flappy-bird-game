#!/usr/bin/env python3
"""
Extended Backend API Testing Script
Additional tests for edge cases and robustness
"""

import requests
import json
import sys
from datetime import datetime

# Backend URL from frontend .env
BACKEND_URL = "https://flappy-highscore-15.preview.emergentagent.com"
API_BASE = f"{BACKEND_URL}/api"

def test_multiple_scores():
    """Test posting multiple scores to verify leaderboard sorting"""
    print("🔍 Testing multiple scores for leaderboard sorting...")
    
    test_scores = [
        {"username": "alice", "score": 25},
        {"username": "bob", "score": 15},
        {"username": "charlie", "score": 35},
        {"username": "diana", "score": 20}
    ]
    
    posted_scores = []
    
    for score_data in test_scores:
        try:
            response = requests.post(
                f"{API_BASE}/score", 
                json=score_data,
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                posted_scores.append(data)
                print(f"   ✅ Posted score: {score_data['username']} - {score_data['score']}")
            else:
                print(f"   ❌ Failed to post score for {score_data['username']}: {response.status_code}")
                return False
                
        except requests.exceptions.RequestException as e:
            print(f"   ❌ Error posting score for {score_data['username']}: {str(e)}")
            return False
    
    # Now check leaderboard sorting
    try:
        response = requests.get(f"{API_BASE}/leaderboard", timeout=10)
        if response.status_code == 200:
            leaderboard = response.json()
            print(f"   Leaderboard: {json.dumps(leaderboard, indent=2)}")
            
            # Verify sorting (should be descending by score)
            scores = [entry['score'] for entry in leaderboard]
            if scores == sorted(scores, reverse=True):
                print("   ✅ Leaderboard is correctly sorted by score (descending)")
                return True
            else:
                print("   ❌ Leaderboard is not properly sorted")
                print(f"   Expected: {sorted(scores, reverse=True)}")
                print(f"   Actual: {scores}")
                return False
        else:
            print(f"   ❌ Failed to get leaderboard: {response.status_code}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"   ❌ Error getting leaderboard: {str(e)}")
        return False

def test_invalid_score_data():
    """Test posting invalid score data"""
    print("\n🔍 Testing invalid score data...")
    
    invalid_cases = [
        {"username": "test", "score": "invalid"},  # Non-numeric score
        {"username": "", "score": 10},  # Empty username
        {"score": 10},  # Missing username
        {"username": "test"},  # Missing score
        {}  # Empty payload
    ]
    
    for i, invalid_data in enumerate(invalid_cases):
        try:
            response = requests.post(
                f"{API_BASE}/score", 
                json=invalid_data,
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            print(f"   Test case {i+1}: {invalid_data}")
            print(f"   Status Code: {response.status_code}")
            
            # We expect 422 (Validation Error) for invalid data
            if response.status_code == 422:
                print(f"   ✅ Correctly rejected invalid data")
            elif response.status_code == 200:
                print(f"   ⚠️  Unexpectedly accepted invalid data")
            else:
                print(f"   ❓ Unexpected status code: {response.status_code}")
                
        except requests.exceptions.RequestException as e:
            print(f"   ❌ Error testing invalid data: {str(e)}")
    
    return True  # This test is informational

def test_root_endpoint():
    """Test the root API endpoint"""
    print("\n🔍 Testing GET /api/ (root endpoint)...")
    
    try:
        response = requests.get(f"{API_BASE}/", timeout=10)
        print(f"   Status Code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"   Response: {json.dumps(data, indent=2)}")
            print("   ✅ GET /api/ - SUCCESS")
            return True
        else:
            print(f"   ❌ GET /api/ - FAILED: Status {response.status_code}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"   ❌ GET /api/ - FAILED: {str(e)}")
        return False

def main():
    """Run extended backend tests"""
    print("🚀 Starting Extended Backend API Tests")
    print(f"Backend URL: {BACKEND_URL}")
    print(f"API Base: {API_BASE}")
    print("=" * 50)
    
    results = []
    
    # Test 1: Root endpoint
    root_result = test_root_endpoint()
    results.append(("GET /api/ (root)", root_result))
    
    # Test 2: Multiple scores and sorting
    sorting_result = test_multiple_scores()
    results.append(("Multiple scores & sorting", sorting_result))
    
    # Test 3: Invalid data handling
    invalid_result = test_invalid_score_data()
    results.append(("Invalid data handling", invalid_result))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 EXTENDED TEST SUMMARY")
    print("=" * 50)
    
    all_passed = True
    for test_name, passed in results:
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{test_name:<30} {status}")
        if not passed:
            all_passed = False
    
    print("=" * 50)
    if all_passed:
        print("🎉 ALL EXTENDED TESTS PASSED!")
        return 0
    else:
        print("💥 SOME EXTENDED TESTS FAILED!")
        return 1

if __name__ == "__main__":
    sys.exit(main())