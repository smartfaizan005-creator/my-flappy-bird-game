# Flappy Bird Game Plan

## Phase 1: Backend Setup (High Scores)
- [ ] Create `Score` model in MongoDB.
- [ ] Implement `GET /api/leaderboard` to fetch top scores.
- [ ] Implement `POST /api/score` to save user scores.
- [ ] Test endpoints with curl.

## Phase 2: Frontend Core Game Loop
- [ ] Setup game constants (gravity, speed, dimensions).
- [ ] Create `Bird` component.
- [ ] Implement physics loop (gravity, jumping).
- [ ] Create `Pipe` manager (spawning, moving, cleanup).

## Phase 3: Collision & Game Logic
- [ ] Implement AABB collision detection (Bird vs Pipes/Ground).
- [ ] Implement scoring logic (passing pipes).
- [ ] Handle Game Over state.

## Phase 4: UI & Polish
- [ ] Create Main Menu (Start Game, Leaderboard).
- [ ] Create Game Screen (Score, Pause/Resume buttons).
- [ ] Create Game Over Screen (Final Score, Replay, Submit Score).
- [ ] Apply "Beautiful Color Accents" (gradients, styling).

## Phase 5: Integration
- [ ] Integrate Leaderboard API.
- [ ] Save high scores to backend.
- [ ] Store local high score using AsyncStorage.
