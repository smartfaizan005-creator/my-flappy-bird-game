import React from 'react';
import { View, StyleSheet, Image } from 'react-native';
import { GAME_CONSTANTS } from '../constants/GameConstants';

interface BirdProps {
  y: number;
  rotation: number;
}

export const Bird: React.FC<BirdProps> = ({ y, rotation }) => {
  return (
    <View
      style={[
        styles.container,
        {
          transform: [
            { translateY: y },
            { rotate: `${rotation}deg` }
          ],
        },
      ]}
    >
      <Image
        source={{ uri: 'https://raw.githubusercontent.com/samuelcust/flappy-bird-assets/master/sprites/yellowbird-midflap.png' }}
        style={styles.birdImage}
        resizeMode="contain"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: GAME_CONSTANTS.WINDOW_WIDTH / 2 - GAME_CONSTANTS.BIRD_SIZE / 2,
    width: GAME_CONSTANTS.BIRD_SIZE,
    height: GAME_CONSTANTS.BIRD_SIZE,
    top: 0,
    zIndex: 20,
  },
  birdImage: {
    width: '100%',
    height: '100%',
  }
});
