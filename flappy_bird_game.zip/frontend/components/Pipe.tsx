import React from 'react';
import { View, StyleSheet, Image } from 'react-native';
import { GAME_CONSTANTS } from '../constants/GameConstants';

interface PipeProps {
  x: number;
  topHeight: number;
}

export const Pipe: React.FC<PipeProps> = ({ x, topHeight }) => {
  const bottomPipeHeight = GAME_CONSTANTS.WINDOW_HEIGHT - topHeight - GAME_CONSTANTS.PIPE_GAP - GAME_CONSTANTS.GROUND_HEIGHT;
  const PIPE_IMAGE = 'https://raw.githubusercontent.com/samuelcust/flappy-bird-assets/master/sprites/pipe-green.png';

  return (
    <View style={[styles.container, { left: x }]}>
      {/* Top Pipe */}
      <View style={[styles.pipeBox, { height: topHeight, top: 0 }]}>
         {/* 
            For the top pipe, we want the cap at the bottom. 
            We rotate the image 180deg.
            We align it to the bottom of the container.
         */}
         <View style={styles.topPipeContainer}>
            <Image 
                source={{ uri: PIPE_IMAGE }} 
                style={styles.pipeImage}
                resizeMode="stretch"
            />
         </View>
      </View>

      {/* Bottom Pipe */}
      <View style={[styles.pipeBox, { height: bottomPipeHeight, top: topHeight + GAME_CONSTANTS.PIPE_GAP }]}>
         {/* 
            For the bottom pipe, we want the cap at the top.
            We align it to the top of the container.
         */}
         <View style={styles.bottomPipeContainer}>
            <Image 
                source={{ uri: PIPE_IMAGE }} 
                style={styles.pipeImage}
                resizeMode="stretch"
            />
         </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    bottom: GAME_CONSTANTS.GROUND_HEIGHT,
    width: GAME_CONSTANTS.PIPE_WIDTH,
    zIndex: 10,
  },
  pipeBox: {
    position: 'absolute',
    width: '100%',
    overflow: 'hidden', // Clip the pipe if it's too long/short
  },
  topPipeContainer: {
      width: '100%',
      height: '100%',
      justifyContent: 'flex-end', // Align to bottom (cap)
  },
  bottomPipeContainer: {
      width: '100%',
      height: '100%',
      justifyContent: 'flex-start', // Align to top (cap)
  },
  pipeImage: {
      width: '100%',
      height: '100%', // Stretch to fill the calculate height
  }
});
