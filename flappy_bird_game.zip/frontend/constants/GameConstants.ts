import { Dimensions } from 'react-native';

const { width, height } = Dimensions.get('window');

export const GAME_CONSTANTS = {
  WINDOW_WIDTH: width,
  WINDOW_HEIGHT: height,
  GRAVITY: 0.6,
  JUMP_STRENGTH: -10, // Negative to go up
  PIPE_SPEED: 3.5,
  PIPE_WIDTH: 60,
  PIPE_GAP: 200,
  BIRD_SIZE: 36,
  SPAWN_RATE: 120, // Frames between pipes approx
  GROUND_HEIGHT: 100,
};
