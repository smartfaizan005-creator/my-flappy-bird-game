import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  ImageBackground,
  Modal,
  TextInput,
  Alert,
  StatusBar,
  Image
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Audio } from 'expo-av';

import { Bird } from '../components/Bird';
import { Pipe } from '../components/Pipe';
import { ScoreBoard } from '../components/ScoreBoard';
import { GAME_CONSTANTS } from '../constants/GameConstants';

// Backend URL
const API_URL = process.env.EXPO_PUBLIC_BACKEND_URL + '/api';

export default function Game() {
  // Game State
  const [gameState, setGameState] = useState<'START' | 'PLAYING' | 'PAUSED' | 'GAME_OVER'>('START');
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [username, setUsername] = useState('');
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [showLeaderboard, setShowLeaderboard] = useState(false);

  // Physics State (Refs for performance)
  const birdY = useRef(GAME_CONSTANTS.WINDOW_HEIGHT / 2);
  const birdVelocity = useRef(0);
  const pipes = useRef<{ x: number; topHeight: number; passed: boolean }[]>([]);
  const frameId = useRef<number>(0);
  const lastTime = useRef<number>(0);
  const spawnTimer = useRef<number>(0);

  // Force render helper
  const [tick, setTick] = useState(0);

  // Sounds
  const [jumpSound, setJumpSound] = useState<Audio.Sound>();

  // Init Sounds and Score
  useEffect(() => {
    fetchHighScore();
  }, []);

  const fetchHighScore = async () => {
    try {
      const stored = await AsyncStorage.getItem('HIGH_SCORE');
      if (stored) setHighScore(parseInt(stored, 10));
      
      const res = await fetch(`${API_URL}/leaderboard`);
      if (res.ok) {
        const data = await res.json();
        setLeaderboard(data);
      }
    } catch (e) {
      console.log('Error fetching scores:', e);
    }
  };

  const startGame = () => {
    birdY.current = GAME_CONSTANTS.WINDOW_HEIGHT / 2;
    birdVelocity.current = 0;
    pipes.current = [];
    setScore(0);
    setGameState('PLAYING');
    lastTime.current = Date.now();
  };

  const jump = () => {
    if (gameState !== 'PLAYING') return;
    birdVelocity.current = GAME_CONSTANTS.JUMP_STRENGTH;
  };

  const pauseGame = () => {
    if (gameState === 'PLAYING') setGameState('PAUSED');
    else if (gameState === 'PAUSED') {
       lastTime.current = Date.now(); 
       setGameState('PLAYING');
    }
  };

  const gameOver = async () => {
    setGameState('GAME_OVER');
    if (score > highScore) {
      setHighScore(score);
      await AsyncStorage.setItem('HIGH_SCORE', score.toString());
    }
  };

  const submitScore = async () => {
    if (!username.trim()) {
      Alert.alert('Error', 'Please enter a username');
      return;
    }
    try {
      await fetch(`${API_URL}/score`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, score })
      });
      Alert.alert('Success', 'Score submitted!');
      fetchHighScore(); 
      setUsername('');
    } catch (e) {
      Alert.alert('Error', 'Failed to submit score');
    }
  };

  // Game Loop
  const update = useCallback(() => {
    if (gameState !== 'PLAYING') return;

    // 1. Update Bird
    birdVelocity.current += GAME_CONSTANTS.GRAVITY;
    birdY.current += birdVelocity.current;

    // 2. Spawn Pipes
    spawnTimer.current++;
    if (spawnTimer.current > GAME_CONSTANTS.SPAWN_RATE) {
      spawnTimer.current = 0;
      const minPipeHeight = 50;
      const maxPipeHeight = GAME_CONSTANTS.WINDOW_HEIGHT - GAME_CONSTANTS.GROUND_HEIGHT - GAME_CONSTANTS.PIPE_GAP - minPipeHeight;
      const randomHeight = Math.floor(Math.random() * (maxPipeHeight - minPipeHeight + 1)) + minPipeHeight;
      
      pipes.current.push({
        x: GAME_CONSTANTS.WINDOW_WIDTH,
        topHeight: randomHeight,
        passed: false
      });
    }

    // 3. Move Pipes & Collision
    const birdRect = {
      top: birdY.current,
      bottom: birdY.current + GAME_CONSTANTS.BIRD_SIZE,
      left: GAME_CONSTANTS.WINDOW_WIDTH / 2 - GAME_CONSTANTS.BIRD_SIZE / 2 + 4, 
      right: GAME_CONSTANTS.WINDOW_WIDTH / 2 + GAME_CONSTANTS.BIRD_SIZE / 2 - 4
    };

    // Ground/Ceiling Collision
    if (birdRect.top < 0 || birdRect.bottom > GAME_CONSTANTS.WINDOW_HEIGHT - GAME_CONSTANTS.GROUND_HEIGHT) {
      gameOver();
      return;
    }

    for (let i = pipes.current.length - 1; i >= 0; i--) {
      const p = pipes.current[i];
      p.x -= GAME_CONSTANTS.PIPE_SPEED;

      if (p.x + GAME_CONSTANTS.PIPE_WIDTH < 0) {
        pipes.current.splice(i, 1);
        continue;
      }

      const pipeLeft = p.x;
      const pipeRight = p.x + GAME_CONSTANTS.PIPE_WIDTH;
      const pipeTopGap = p.topHeight;
      const pipeBottomGap = p.topHeight + GAME_CONSTANTS.PIPE_GAP;

      if (birdRect.right > pipeLeft && birdRect.left < pipeRight) {
        if (birdRect.top < pipeTopGap || birdRect.bottom > pipeBottomGap) {
           gameOver();
           return;
        }
      }

      if (!p.passed && birdRect.left > pipeRight) {
        p.passed = true;
        setScore(s => s + 1);
      }
    }

    setTick(t => t + 1);
    frameId.current = requestAnimationFrame(update);
  }, [gameState]);

  useEffect(() => {
    if (gameState === 'PLAYING') {
      frameId.current = requestAnimationFrame(update);
    }
    return () => cancelAnimationFrame(frameId.current);
  }, [gameState, update]);

  const rotation = Math.min(Math.max(birdVelocity.current * 3, -25), 90);

  return (
    <View style={styles.container}>
      <StatusBar hidden />
      
      {/* Background Image */}
      <ImageBackground
        source={{ uri: 'https://raw.githubusercontent.com/samuelcust/flappy-bird-assets/master/sprites/background-day.png' }}
        style={styles.backgroundImage}
        resizeMode="cover"
      >
          {/* Game World */}
          <View style={styles.gameArea} onTouchStart={jump}>
            {pipes.current.map((p, i) => (
              <Pipe key={`pipe-${i}`} x={p.x} topHeight={p.topHeight} />
            ))}
            
            <Bird y={birdY.current} rotation={rotation} />

            {/* Ground */}
            <View style={styles.ground}>
                <Image 
                    source={{ uri: 'https://raw.githubusercontent.com/samuelcust/flappy-bird-assets/master/sprites/base.png' }}
                    style={{ width: '100%', height: '100%' }}
                    resizeMode="cover"
                />
            </View>
          </View>

          {/* UI Layer */}
          <ScoreBoard score={score} highScore={highScore} />

          {/* Controls */}
          {gameState === 'PLAYING' && (
            <TouchableOpacity style={styles.pauseBtn} onPress={pauseGame}>
              <Text style={styles.btnText}>II</Text>
            </TouchableOpacity>
          )}

          {/* Menus */}
          {gameState === 'START' && (
            <View style={styles.overlay}>
              <Text style={styles.title}>FLAPPY BIRD</Text>
              <TouchableOpacity style={styles.button} onPress={startGame}>
                <Text style={styles.buttonText}>PLAY</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.button, { marginTop: 10, backgroundColor: '#E0A800' }]} onPress={() => setShowLeaderboard(true)}>
                <Text style={styles.buttonText}>RANK</Text>
              </TouchableOpacity>
            </View>
          )}

          {gameState === 'PAUSED' && (
            <View style={styles.overlay}>
              <Text style={styles.title}>PAUSED</Text>
              <TouchableOpacity style={styles.button} onPress={pauseGame}>
                <Text style={styles.buttonText}>RESUME</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.button, { marginTop: 10, backgroundColor: '#FF4500' }]} onPress={() => setGameState('START')}>
                <Text style={styles.buttonText}>QUIT</Text>
              </TouchableOpacity>
            </View>
          )}

          {gameState === 'GAME_OVER' && (
            <View style={styles.overlay}>
              <Text style={styles.title}>GAME OVER</Text>
              <View style={styles.scoreCard}>
                <Text style={styles.cardTitle}>SCORE</Text>
                <Text style={styles.cardScore}>{score}</Text>
                <Text style={styles.cardTitle}>BEST</Text>
                <Text style={styles.cardScore}>{highScore}</Text>
              </View>
              
              <TextInput
                style={styles.input}
                placeholder="Enter Name"
                placeholderTextColor="#CCC"
                value={username}
                onChangeText={setUsername}
              />
              <TouchableOpacity style={[styles.button, { width: 200, marginBottom: 10 }]} onPress={submitScore}>
                <Text style={styles.buttonText}>SAVE</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.button} onPress={startGame}>
                <Text style={styles.buttonText}>RETRY</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.button, { marginTop: 10, backgroundColor: '#888' }]} onPress={() => setGameState('START')}>
                <Text style={styles.buttonText}>MENU</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* Leaderboard Modal */}
          <Modal visible={showLeaderboard} animationType="slide" transparent>
            <View style={styles.modalContainer}>
              <View style={styles.modalContent}>
                <Text style={styles.modalTitle}>LEADERBOARD</Text>
                {leaderboard.map((s, i) => (
                  <View key={i} style={styles.scoreRow}>
                    <Text style={styles.rank}>#{i + 1}</Text>
                    <Text style={styles.name}>{s.username}</Text>
                    <Text style={styles.points}>{s.score}</Text>
                  </View>
                ))}
                <TouchableOpacity style={[styles.button, { marginTop: 20 }]} onPress={() => setShowLeaderboard(false)}>
                  <Text style={styles.buttonText}>CLOSE</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>
      </ImageBackground>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  gameArea: {
    flex: 1,
    position: 'relative',
  },
  ground: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    height: GAME_CONSTANTS.GROUND_HEIGHT,
    zIndex: 5,
    borderTopWidth: 2,
    borderColor: '#553c22'
  },
  pauseBtn: {
    position: 'absolute',
    top: 50,
    right: 20,
    width: 40,
    height: 40,
    backgroundColor: 'rgba(255,255,255,0.8)',
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 20,
    borderWidth: 2,
    borderColor: '#000'
  },
  btnText: {
    fontWeight: '900',
    fontSize: 16,
    color: '#000',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 50,
  },
  title: {
    fontSize: 48,
    fontWeight: '900',
    color: '#fcba03',
    marginBottom: 40,
    textShadowColor: '#000',
    textShadowOffset: { width: 4, height: 4 },
    textShadowRadius: 0, // Pixel art style shadow (hard)
    letterSpacing: 2,
  },
  button: {
    backgroundColor: '#e3d64b', // Classic button color
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 5,
    borderWidth: 2,
    borderColor: '#FFF',
    elevation: 5,
    minWidth: 140,
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFF',
    fontSize: 20,
    fontWeight: '900',
    textShadowColor: '#000',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 0,
  },
  scoreCard: {
    backgroundColor: '#ded895',
    padding: 20,
    borderRadius: 5,
    borderWidth: 2,
    borderColor: '#553c22',
    alignItems: 'center',
    width: 260,
    marginBottom: 20,
  },
  cardTitle: {
    fontSize: 18,
    color: '#e86101',
    fontWeight: '900',
    marginBottom: 5,
  },
  cardScore: {
    fontSize: 32,
    color: '#FFF',
    fontWeight: '900',
    textShadowColor: '#000',
    textShadowOffset: {width: 2, height:2},
    textShadowRadius: 0,
    marginBottom: 15,
  },
  input: {
    width: 250,
    height: 50,
    backgroundColor: '#FFF',
    borderRadius: 5,
    paddingHorizontal: 15,
    fontSize: 18,
    marginBottom: 10,
    textAlign: 'center',
    borderWidth: 2,
    borderColor: '#000'
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '85%',
    backgroundColor: '#ded895',
    borderRadius: 5,
    padding: 20,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#553c22',
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: '900',
    marginBottom: 20,
    color: '#e86101',
    textShadowColor: '#000',
    textShadowOffset: {width: 1, height:1},
    textShadowRadius: 0,
  },
  scoreRow: {
    flexDirection: 'row',
    width: '100%',
    paddingVertical: 10,
    borderBottomWidth: 2,
    borderBottomColor: '#d0c874',
  },
  rank: {
    width: 40,
    fontWeight: 'bold',
    fontSize: 18,
    color: '#e86101',
  },
  name: {
    flex: 1,
    fontSize: 18,
    color: '#553c22',
    fontWeight: 'bold',
  },
  points: {
    fontWeight: 'bold',
    fontSize: 18,
    color: '#FFF',
    textShadowColor: '#000',
    textShadowOffset: {width: 1, height:1},
    textShadowRadius: 0,
  }
});
