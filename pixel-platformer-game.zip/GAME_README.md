# 🎮 Pixel Platformer Game

A classic mobile platformer game built with Expo and React Native, inspired by Kenney's Pixel Platformer assets.

## 🎯 Features

- **3 Challenging Levels**: Progress through increasingly difficult stages
  - Level 1: Getting Started
  - Level 2: Jump Higher  
  - Level 3: Coin Rush

- **Mobile-Optimized Controls**:
  - Left/Right arrow buttons for movement
  - Jump button for jumping
  - Touch-friendly interface

- **Game Mechanics**:
  - Realistic physics with gravity
  - Platform collision detection
  - Coin collection system
  - Score tracking (+10 points per coin)
  - Level progression
  - Game Over/Win screens

- **Cross-Platform**: Works on both Android and iOS devices

## 🎮 How to Play

1. Tap "START GAME" from the main menu
2. Use left/right arrows to move your character
3. Tap the jump button to jump
4. Collect all coins in each level to progress
5. Don't fall off the platforms!
6. Complete all 3 levels to win

## 📱 Running the Game

### On Your Mobile Device (Recommended)

1. Install Expo Go app from Play Store (Android) or App Store (iOS)
2. Scan the QR code displayed in the terminal
3. Start playing!

### On Web Browser

Navigate to `http://localhost:3000` (for development only)

## 🛠️ Tech Stack

- **Frontend**: React Native, Expo Router
- **Game Engine**: Custom game loop with physics
- **Language**: TypeScript
- **Styling**: React Native StyleSheet

## 🎨 Game Design

- Sky blue background for outdoor atmosphere
- Pixel art style elements
- Color-coded UI elements:
  - Red player character
  - Brown platforms
  - Golden coins
  - Green action buttons

## 📝 Game Controls

- **← Button**: Move left
- **→ Button**: Move right  
- **JUMP Button**: Jump (only works when on ground)

## 🏆 Winning Condition

Collect all coins in all 3 levels to complete the game!

## 💡 Tips

- Time your jumps carefully
- Some platforms are higher - you may need to jump from platform to platform
- Don't rush - falling off means game over!
- Collect coins in the order that makes the most sense for your path

## 📄 Credits

Game concept inspired by Kenney's Pixel Platformer asset pack (CC0 License)

---

**Made with ❤️ using Expo and React Native**
