import { Dimensions } from 'react-native';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

export const levels = [
  {
    name: 'Getting Started',
    playerStart: { x: 60, y: SCREEN_HEIGHT - 200 },
    platforms: [
      { x: 60, y: SCREEN_HEIGHT - 100, width: 120, height: 20 },
      { x: 200, y: SCREEN_HEIGHT - 150, width: 100, height: 20 },
      { x: 340, y: SCREEN_HEIGHT - 200, width: 100, height: 20 },
      { x: SCREEN_WIDTH - 60, y: SCREEN_HEIGHT - 250, width: 120, height: 20 },
    ],
    coins: [
      { x: 200, y: SCREEN_HEIGHT - 200 },
      { x: 340, y: SCREEN_HEIGHT - 250 },
      { x: SCREEN_WIDTH - 60, y: SCREEN_HEIGHT - 300 },
    ],
  },
  {
    name: 'Jump Higher',
    playerStart: { x: 60, y: SCREEN_HEIGHT - 200 },
    platforms: [
      { x: 60, y: SCREEN_HEIGHT - 100, width: 100, height: 20 },
      { x: 180, y: SCREEN_HEIGHT - 180, width: 80, height: 20 },
      { x: 300, y: SCREEN_HEIGHT - 260, width: 80, height: 20 },
      { x: SCREEN_WIDTH / 2, y: SCREEN_HEIGHT - 340, width: 100, height: 20 },
      { x: SCREEN_WIDTH - 80, y: SCREEN_HEIGHT - 260, width: 80, height: 20 },
      { x: SCREEN_WIDTH - 60, y: SCREEN_HEIGHT - 150, width: 100, height: 20 },
    ],
    coins: [
      { x: 180, y: SCREEN_HEIGHT - 230 },
      { x: 300, y: SCREEN_HEIGHT - 310 },
      { x: SCREEN_WIDTH / 2, y: SCREEN_HEIGHT - 390 },
      { x: SCREEN_WIDTH - 80, y: SCREEN_HEIGHT - 310 },
      { x: SCREEN_WIDTH - 60, y: SCREEN_HEIGHT - 200 },
    ],
  },
  {
    name: 'Coin Rush',
    playerStart: { x: 60, y: SCREEN_HEIGHT - 200 },
    platforms: [
      { x: 60, y: SCREEN_HEIGHT - 100, width: 120, height: 20 },
      { x: SCREEN_WIDTH / 4, y: SCREEN_HEIGHT - 180, width: 100, height: 20 },
      { x: SCREEN_WIDTH / 2, y: SCREEN_HEIGHT - 240, width: 120, height: 20 },
      { x: (SCREEN_WIDTH * 3) / 4, y: SCREEN_HEIGHT - 180, width: 100, height: 20 },
      { x: SCREEN_WIDTH - 60, y: SCREEN_HEIGHT - 100, width: 120, height: 20 },
    ],
    coins: [
      { x: SCREEN_WIDTH / 4, y: SCREEN_HEIGHT - 230 },
      { x: SCREEN_WIDTH / 2 - 40, y: SCREEN_HEIGHT - 290 },
      { x: SCREEN_WIDTH / 2, y: SCREEN_HEIGHT - 300 },
      { x: SCREEN_WIDTH / 2 + 40, y: SCREEN_HEIGHT - 290 },
      { x: (SCREEN_WIDTH * 3) / 4, y: SCREEN_HEIGHT - 230 },
      { x: SCREEN_WIDTH - 60, y: SCREEN_HEIGHT - 150 },
    ],
  },
];