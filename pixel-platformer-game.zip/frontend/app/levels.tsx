import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { levels } from '../constants/levels';

export default function Levels() {
  const router = useRouter();

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Text style={styles.backButtonText}>← BACK</Text>
        </TouchableOpacity>
        <Text style={styles.title}>SELECT LEVEL</Text>
      </View>

      <ScrollView style={styles.levelList} contentContainerStyle={styles.levelListContent}>
        {levels.map((level, index) => (
          <TouchableOpacity
            key={index}
            style={styles.levelCard}
            onPress={() => router.push('/game')}
          >
            <Text style={styles.levelNumber}>{index + 1}</Text>
            <View style={styles.levelInfo}>
              <Text style={styles.levelName}>{level.name}</Text>
              <Text style={styles.levelCoins}>Coins: {level.coins.length}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#87CEEB',
  },
  header: {
    padding: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
  },
  backButton: {
    marginBottom: 10,
  },
  backButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
  },
  levelList: {
    flex: 1,
  },
  levelListContent: {
    padding: 20,
    gap: 16,
  },
  levelCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#333',
  },
  levelNumber: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#4CAF50',
    marginRight: 20,
    width: 60,
  },
  levelInfo: {
    flex: 1,
  },
  levelName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  levelCoins: {
    fontSize: 14,
    color: '#666',
  },
});