import React, { useState, useEffect, useRef } from 'react';
import { View, StyleSheet, Dimensions, Text, TouchableOpacity, Animated } from 'react-native';
import { useRouter } from 'expo-router';
import Player from './components/Player';
import Platform from './components/Platform';
import Coin from './components/Coin';
import Controls from './components/Controls';
import { levels } from '../constants/levels';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');
const GRAVITY = 0.8;
const JUMP_FORCE = -15;
const MOVE_SPEED = 5;

export default function Game() {
  const router = useRouter();
  const [score, setScore] = useState(0);
  const [collectedCoins, setCollectedCoins] = useState<Set<number>>(new Set());
  const [currentLevel, setCurrentLevel] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [won, setWon] = useState(false);
  
  const [playerPos, setPlayerPos] = useState({ x: 0, y: 0 });
  const [playerVelocity, setPlayerVelocity] = useState({ x: 0, y: 0 });
  const [controlState, setControlState] = useState({ left: false, right: false, jump: false });
  const [isOnGround, setIsOnGround] = useState(false);

  const gameLoopRef = useRef<NodeJS.Timeout | null>(null);
  const level = levels[currentLevel];

  // Initialize player position
  useEffect(() => {
    setPlayerPos({ x: level.playerStart.x, y: level.playerStart.y });
    setPlayerVelocity({ x: 0, y: 0 });
    setCollectedCoins(new Set());
  }, [currentLevel]);

  // Game loop
  useEffect(() => {
    gameLoopRef.current = setInterval(() => {
      setPlayerPos(prevPos => {
        setPlayerVelocity(prevVel => {
          let newVelX = prevVel.x;
          let newVelY = prevVel.y;

          // Horizontal movement
          if (controlState.left) {
            newVelX = -MOVE_SPEED;
          } else if (controlState.right) {
            newVelX = MOVE_SPEED;
          } else {
            newVelX = 0;
          }

          // Gravity
          newVelY += GRAVITY;

          // Calculate new position
          let newX = prevPos.x + newVelX;
          let newY = prevPos.y + newVelY;

          // Check collisions with platforms
          let onGround = false;
          level.platforms.forEach(platform => {
            const playerLeft = newX - 15;
            const playerRight = newX + 15;
            const playerTop = newY - 20;
            const playerBottom = newY + 20;

            const platLeft = platform.x - platform.width / 2;
            const platRight = platform.x + platform.width / 2;
            const platTop = platform.y - platform.height / 2;
            const platBottom = platform.y + platform.height / 2;

            // Check if player is colliding with platform
            if (playerRight > platLeft && playerLeft < platRight) {
              // Landing on top
              if (prevPos.y + 20 <= platTop && playerBottom >= platTop && newVelY > 0) {
                newY = platTop - 20;
                newVelY = 0;
                onGround = true;
              }
              // Hitting from bottom
              else if (prevPos.y - 20 >= platBottom && playerTop <= platBottom && newVelY < 0) {
                newY = platBottom + 20;
                newVelY = 0;
              }
            }
          });

          setIsOnGround(onGround);

          // Jump
          if (controlState.jump && onGround) {
            newVelY = JUMP_FORCE;
            controlState.jump = false;
          }

          // Check coin collection
          level.coins.forEach((coin, index) => {
            const dist = Math.sqrt(Math.pow(newX - coin.x, 2) + Math.pow(newY - coin.y, 2));
            if (dist < 25 && !collectedCoins.has(index)) {
              setCollectedCoins(prev => new Set([...prev, index]));
              setScore(s => s + 10);
            }
          });

          // Check boundaries
          if (newX < 15) newX = 15;
          if (newX > SCREEN_WIDTH - 15) newX = SCREEN_WIDTH - 15;

          // Check if fell off
          if (newY > SCREEN_HEIGHT + 50) {
            setGameOver(true);
          }

          return { x: newVelX, y: newVelY };
        });

        return { x: newX, y: newY };
      });
    }, 1000 / 60); // 60 FPS

    return () => {
      if (gameLoopRef.current) {
        clearInterval(gameLoopRef.current);
      }
    };
  }, [controlState, level, collectedCoins]);

  // Check win condition
  useEffect(() => {
    if (collectedCoins.size >= level.coins.length && collectedCoins.size > 0) {
      if (currentLevel < levels.length - 1) {
        setTimeout(() => {
          setCurrentLevel(prev => prev + 1);
          setCollectedCoins(new Set());
        }, 1000);
      } else {
        setWon(true);
      }
    }
  }, [collectedCoins.size]);

  const resetGame = () => {
    setScore(0);
    setCollectedCoins(new Set());
    setGameOver(false);
    setWon(false);
    setPlayerPos({ x: level.playerStart.x, y: level.playerStart.y });
    setPlayerVelocity({ x: 0, y: 0 });
    setControlState({ left: false, right: false, jump: false });
  };

  return (
    <View style={styles.container}>
      <View style={styles.hud}>
        <Text style={styles.hudText}>Level: {currentLevel + 1}</Text>
        <Text style={styles.hudText}>Score: {score}</Text>
        <Text style={styles.hudText}>Coins: {collectedCoins.size}/{level.coins.length}</Text>
      </View>

      {!gameOver && !won && (
        <View style={styles.gameContainer}>
          {/* Platforms */}
          {level.platforms.map((platform, index) => (
            <Platform key={index} x={platform.x} y={platform.y} width={platform.width} height={platform.height} />
          ))}

          {/* Coins */}
          {level.coins.map((coin, index) => (
            !collectedCoins.has(index) && (
              <Coin key={index} x={coin.x} y={coin.y} />
            )
          ))}

          {/* Player */}
          <Player x={playerPos.x} y={playerPos.y} />
        </View>
      )}

      {(gameOver || won) && (
        <View style={styles.overlay}>
          <View style={styles.modal}>
            <Text style={styles.modalTitle}>{won ? 'YOU WON!' : 'GAME OVER'}</Text>
            <Text style={styles.modalScore}>Final Score: {score}</Text>
            
            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.modalButton} onPress={resetGame}>
                <Text style={styles.modalButtonText}>RETRY</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[styles.modalButton, styles.secondaryModalButton]} 
                onPress={() => router.back()}
              >
                <Text style={styles.modalButtonText}>MENU</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      )}

      {!gameOver && !won && (
        <Controls onControlChange={setControlState} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#87CEEB',
  },
  gameContainer: {
    flex: 1,
  },
  hud: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 16,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  hudText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modal: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 32,
    alignItems: 'center',
    minWidth: 280,
    borderWidth: 4,
    borderColor: '#333',
  },
  modalTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  modalScore: {
    fontSize: 20,
    color: '#666',
    marginBottom: 24,
  },
  modalButtons: {
    gap: 12,
    width: '100%',
  },
  modalButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    borderWidth: 3,
    borderColor: '#2E7D32',
    alignItems: 'center',
  },
  secondaryModalButton: {
    backgroundColor: '#666',
    borderColor: '#444',
  },
  modalButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
