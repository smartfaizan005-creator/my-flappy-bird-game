import React, { useState } from 'react';
import { View, StyleSheet, TouchableOpacity, Text } from 'react-native';

interface ControlsProps {
  onControlChange: (state: { left: boolean; right: boolean; jump: boolean }) => void;
}

const Controls = ({ onControlChange }: ControlsProps) => {
  const [controlState, setControlState] = useState({ left: false, right: false, jump: false });

  const updateControl = (key: 'left' | 'right' | 'jump', value: boolean) => {
    const newState = { ...controlState, [key]: value };
    setControlState(newState);
    onControlChange(newState);
  };

  return (
    <View style={styles.container}>
      <View style={styles.leftControls}>
        <View style={styles.dpad}>
          <TouchableOpacity
            style={[styles.dpadButton, styles.leftButton]}
            onPressIn={() => updateControl('left', true)}
            onPressOut={() => updateControl('left', false)}
          >
            <Text style={styles.buttonText}>←</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.dpadButton, styles.rightButton]}
            onPressIn={() => updateControl('right', true)}
            onPressOut={() => updateControl('right', false)}
          >
            <Text style={styles.buttonText}>→</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.rightControls}>
        <TouchableOpacity
          style={styles.jumpButton}
          onPressIn={() => updateControl('jump', true)}
          onPressOut={() => updateControl('jump', false)}
        >
          <Text style={styles.jumpButtonText}>JUMP</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 150,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    padding: 20,
    backgroundColor: 'transparent',
  },
  leftControls: {
    flex: 1,
  },
  rightControls: {
    flex: 1,
    alignItems: 'flex-end',
  },
  dpad: {
    flexDirection: 'row',
    gap: 10,
  },
  dpadButton: {
    width: 60,
    height: 60,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  leftButton: {},
  rightButton: {},
  buttonText: {
    color: '#fff',
    fontSize: 28,
    fontWeight: 'bold',
  },
  jumpButton: {
    width: 80,
    height: 80,
    backgroundColor: 'rgba(76, 175, 80, 0.7)',
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 4,
    borderColor: 'rgba(46, 125, 50, 0.8)',
  },
  jumpButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default Controls;