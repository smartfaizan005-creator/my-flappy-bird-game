import React from 'react';
import { View } from 'react-native';

interface CoinProps {
  x: number;
  y: number;
}

const Coin = ({ x, y }: CoinProps) => {
  const radius = 12;

  return (
    <View
      style={{
        position: 'absolute',
        left: x - radius,
        top: y - radius,
        width: radius * 2,
        height: radius * 2,
        backgroundColor: '#FFD700',
        borderRadius: radius,
        borderWidth: 2,
        borderColor: '#FFA500',
      }}
    />
  );
};

export default Coin;