import React from 'react';
import { View } from 'react-native';

interface PlatformProps {
  x: number;
  y: number;
  width: number;
  height: number;
}

const Platform = ({ x, y, width, height }: PlatformProps) => {
  return (
    <View
      style={{
        position: 'absolute',
        left: x - width / 2,
        top: y - height / 2,
        width: width,
        height: height,
        backgroundColor: '#8B4513',
        borderRadius: 2,
        borderWidth: 2,
        borderColor: '#654321',
      }}
    />
  );
};

export default Platform;