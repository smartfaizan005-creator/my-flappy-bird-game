import React from 'react';
import { View } from 'react-native';

interface PlayerProps {
  x: number;
  y: number;
}

const Player = ({ x, y }: PlayerProps) => {
  return (
    <View
      style={{
        position: 'absolute',
        left: x - 15,
        top: y - 20,
        width: 30,
        height: 40,
        backgroundColor: '#FF6B6B',
        borderRadius: 4,
        borderWidth: 2,
        borderColor: '#C92A2A',
      }}
    />
  );
};

export default Player;