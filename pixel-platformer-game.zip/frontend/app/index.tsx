import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ImageBackground } from 'react-native';
import { useRouter } from 'expo-router';

export default function Index() {
  const router = useRouter();

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>PIXEL</Text>
        <Text style={styles.title}>PLATFORMER</Text>
        
        <View style={styles.menu}>
          <TouchableOpacity 
            style={styles.button}
            onPress={() => router.push('/game')}
          >
            <Text style={styles.buttonText}>START GAME</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.button, styles.secondaryButton]}
            onPress={() => router.push('/levels')}
          >
            <Text style={styles.buttonText}>LEVELS</Text>
          </TouchableOpacity>
        </View>
        
        <Text style={styles.credits}>Made with Kenney Assets</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#87CEEB',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#fff',
    textShadowColor: '#000',
    textShadowOffset: { width: 4, height: 4 },
    textShadowRadius: 0,
    letterSpacing: 2,
  },
  menu: {
    marginTop: 60,
    gap: 20,
    width: '100%',
    maxWidth: 300,
  },
  button: {
    backgroundColor: '#4CAF50',
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 8,
    borderWidth: 4,
    borderColor: '#2E7D32',
    alignItems: 'center',
  },
  secondaryButton: {
    backgroundColor: '#2196F3',
    borderColor: '#1565C0',
  },
  buttonText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    textShadowColor: '#000',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 0,
  },
  credits: {
    position: 'absolute',
    bottom: 20,
    fontSize: 12,
    color: '#fff',
    opacity: 0.7,
  },
});