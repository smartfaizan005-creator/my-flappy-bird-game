import Matter from 'matter-js';

const Physics = (entities: any, { time }: any) => {
  const engine = entities.physics.engine;
  const player = entities.player?.body;
  const controlState = entities.player?.controlState;

  if (player && controlState) {
    const moveSpeed = 5;
    const jumpForce = -0.15;

    // Horizontal movement
    if (controlState.left) {
      Matter.Body.setVelocity(player, {
        x: -moveSpeed,
        y: player.velocity.y,
      });
    } else if (controlState.right) {
      Matter.Body.setVelocity(player, {
        x: moveSpeed,
        y: player.velocity.y,
      });
    } else {
      // Apply friction when not moving
      Matter.Body.setVelocity(player, {
        x: player.velocity.x * 0.9,
        y: player.velocity.y,
      });
    }

    // Jump (only if on ground)
    if (controlState.jump && Math.abs(player.velocity.y) < 0.5) {
      Matter.Body.applyForce(player, player.position, {
        x: 0,
        y: jumpForce,
      });
      // Reset jump to prevent continuous jumping
      controlState.jump = false;
    }
  }

  Matter.Engine.update(engine, time.delta);
  return entities;
};

export { Physics };