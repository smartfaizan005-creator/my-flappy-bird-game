import React, { useState, useEffect, useRef, useCallback } from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route, useNavigate, useSearchParams } from "react-router-dom";

// Game constants
const GRAVITY = 0.8;
const JUMP_FORCE = -15;
const MOVE_SPEED = 5;
const PLAYER_WIDTH = 30;
const PLAYER_HEIGHT = 40;

// Level data
const createLevels = (screenWidth, screenHeight) => [
  {
    name: 'Getting Started',
    playerStart: { x: 60, y: screenHeight - 200 },
    platforms: [
      { x: 60, y: screenHeight - 100, width: 120, height: 20 },
      { x: 200, y: screenHeight - 150, width: 100, height: 20 },
      { x: 340, y: screenHeight - 200, width: 100, height: 20 },
      { x: screenWidth - 60, y: screenHeight - 250, width: 120, height: 20 },
    ],
    coins: [
      { x: 200, y: screenHeight - 200 },
      { x: 340, y: screenHeight - 250 },
      { x: screenWidth - 60, y: screenHeight - 300 },
    ],
  },
  {
    name: 'Jump Higher',
    playerStart: { x: 60, y: screenHeight - 200 },
    platforms: [
      { x: 60, y: screenHeight - 100, width: 100, height: 20 },
      { x: 180, y: screenHeight - 180, width: 80, height: 20 },
      { x: 300, y: screenHeight - 260, width: 80, height: 20 },
      { x: screenWidth / 2, y: screenHeight - 340, width: 100, height: 20 },
      { x: screenWidth - 80, y: screenHeight - 260, width: 80, height: 20 },
      { x: screenWidth - 60, y: screenHeight - 150, width: 100, height: 20 },
    ],
    coins: [
      { x: 180, y: screenHeight - 230 },
      { x: 300, y: screenHeight - 310 },
      { x: screenWidth / 2, y: screenHeight - 390 },
      { x: screenWidth - 80, y: screenHeight - 310 },
      { x: screenWidth - 60, y: screenHeight - 200 },
    ],
  },
  {
    name: 'Coin Rush',
    playerStart: { x: 60, y: screenHeight - 200 },
    platforms: [
      { x: 60, y: screenHeight - 100, width: 120, height: 20 },
      { x: screenWidth / 4, y: screenHeight - 180, width: 100, height: 20 },
      { x: screenWidth / 2, y: screenHeight - 240, width: 120, height: 20 },
      { x: (screenWidth * 3) / 4, y: screenHeight - 180, width: 100, height: 20 },
      { x: screenWidth - 60, y: screenHeight - 100, width: 120, height: 20 },
    ],
    coins: [
      { x: screenWidth / 4, y: screenHeight - 230 },
      { x: screenWidth / 2 - 40, y: screenHeight - 290 },
      { x: screenWidth / 2, y: screenHeight - 300 },
      { x: screenWidth / 2 + 40, y: screenHeight - 290 },
      { x: (screenWidth * 3) / 4, y: screenHeight - 230 },
      { x: screenWidth - 60, y: screenHeight - 150 },
    ],
  },
];

// Player Component
const Player = ({ x, y }) => (
  <div
    data-testid="player"
    style={{
      position: 'absolute',
      left: x - PLAYER_WIDTH / 2,
      top: y - PLAYER_HEIGHT / 2,
      width: PLAYER_WIDTH,
      height: PLAYER_HEIGHT,
      backgroundColor: '#FF6B6B',
      borderRadius: 4,
      border: '2px solid #C92A2A',
      zIndex: 10,
    }}
  />
);

// Platform Component
const Platform = ({ x, y, width, height }) => (
  <div
    data-testid="platform"
    style={{
      position: 'absolute',
      left: x - width / 2,
      top: y - height / 2,
      width,
      height,
      backgroundColor: '#8B4513',
      borderRadius: 2,
      border: '2px solid #654321',
    }}
  />
);

// Coin Component
const Coin = ({ x, y }) => (
  <div
    data-testid="coin"
    style={{
      position: 'absolute',
      left: x - 12,
      top: y - 12,
      width: 24,
      height: 24,
      backgroundColor: '#FFD700',
      borderRadius: '50%',
      border: '2px solid #FFA500',
      boxShadow: '0 0 10px rgba(255, 215, 0, 0.5)',
    }}
  />
);

// Controls Component
const Controls = ({ onControlChange }) => {
  const handlePressStart = (key) => {
    onControlChange(prev => ({ ...prev, [key]: true }));
  };

  const handlePressEnd = (key) => {
    onControlChange(prev => ({ ...prev, [key]: false }));
  };

  return (
    <div style={{
      position: 'absolute',
      bottom: 0,
      left: 0,
      right: 0,
      height: 150,
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      padding: 20,
      pointerEvents: 'auto',
    }}>
      <div style={{ display: 'flex', gap: 10 }}>
        <button
          data-testid="left-btn"
          onMouseDown={() => handlePressStart('left')}
          onMouseUp={() => handlePressEnd('left')}
          onMouseLeave={() => handlePressEnd('left')}
          onTouchStart={() => handlePressStart('left')}
          onTouchEnd={() => handlePressEnd('left')}
          style={{
            width: 60,
            height: 60,
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            borderRadius: '50%',
            border: '3px solid rgba(255, 255, 255, 0.3)',
            color: '#fff',
            fontSize: 28,
            fontWeight: 'bold',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            userSelect: 'none',
          }}
        >
          ←
        </button>
        <button
          data-testid="right-btn"
          onMouseDown={() => handlePressStart('right')}
          onMouseUp={() => handlePressEnd('right')}
          onMouseLeave={() => handlePressEnd('right')}
          onTouchStart={() => handlePressStart('right')}
          onTouchEnd={() => handlePressEnd('right')}
          style={{
            width: 60,
            height: 60,
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            borderRadius: '50%',
            border: '3px solid rgba(255, 255, 255, 0.3)',
            color: '#fff',
            fontSize: 28,
            fontWeight: 'bold',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            userSelect: 'none',
          }}
        >
          →
        </button>
      </div>
      <button
        data-testid="jump-btn"
        onMouseDown={() => handlePressStart('jump')}
        onMouseUp={() => handlePressEnd('jump')}
        onMouseLeave={() => handlePressEnd('jump')}
        onTouchStart={() => handlePressStart('jump')}
        onTouchEnd={() => handlePressEnd('jump')}
        style={{
          width: 80,
          height: 80,
          backgroundColor: 'rgba(76, 175, 80, 0.7)',
          borderRadius: '50%',
          border: '4px solid rgba(46, 125, 50, 0.8)',
          color: '#fff',
          fontSize: 16,
          fontWeight: 'bold',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          userSelect: 'none',
        }}
      >
        JUMP
      </button>
    </div>
  );
};

// Game Component
const Game = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const startLevel = parseInt(searchParams.get('level') || '0', 10);
  
  const [screenSize, setScreenSize] = useState({ width: 800, height: 600 });
  const [levels, setLevels] = useState([]);
  const [score, setScore] = useState(0);
  const [collectedCoins, setCollectedCoins] = useState(new Set());
  const [currentLevel, setCurrentLevel] = useState(startLevel);
  const [gameOver, setGameOver] = useState(false);
  const [won, setWon] = useState(false);
  const [renderState, setRenderState] = useState({ x: 0, y: 0 });
  const [controlState, setControlState] = useState({ left: false, right: false, jump: false });
  
  const gameStateRef = useRef({
    playerX: 0,
    playerY: 0,
    velocityX: 0,
    velocityY: 0,
    isOnGround: false,
  });
  const collectedCoinsRef = useRef(new Set());
  const gameLoopRef = useRef(null);
  const gameContainerRef = useRef(null);

  // Initialize screen size and levels
  useEffect(() => {
    const updateSize = () => {
      const width = Math.min(window.innerWidth, 800);
      const height = Math.min(window.innerHeight - 50, 600);
      setScreenSize({ width, height });
      setLevels(createLevels(width, height));
    };
    updateSize();
    window.addEventListener('resize', updateSize);
    return () => window.removeEventListener('resize', updateSize);
  }, []);

  // Initialize player position when level changes
  useEffect(() => {
    if (levels.length === 0) return;
    const level = levels[currentLevel];
    if (!level) return;
    
    gameStateRef.current = {
      playerX: level.playerStart.x,
      playerY: level.playerStart.y,
      velocityX: 0,
      velocityY: 0,
      isOnGround: false,
    };
    setRenderState({ x: level.playerStart.x, y: level.playerStart.y });
    collectedCoinsRef.current = new Set();
    setCollectedCoins(new Set());
  }, [currentLevel, levels]);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'ArrowLeft' || e.key === 'a') {
        setControlState(prev => ({ ...prev, left: true }));
      }
      if (e.key === 'ArrowRight' || e.key === 'd') {
        setControlState(prev => ({ ...prev, right: true }));
      }
      if (e.key === ' ' || e.key === 'ArrowUp' || e.key === 'w') {
        e.preventDefault();
        setControlState(prev => ({ ...prev, jump: true }));
      }
    };

    const handleKeyUp = (e) => {
      if (e.key === 'ArrowLeft' || e.key === 'a') {
        setControlState(prev => ({ ...prev, left: false }));
      }
      if (e.key === 'ArrowRight' || e.key === 'd') {
        setControlState(prev => ({ ...prev, right: false }));
      }
      if (e.key === ' ' || e.key === 'ArrowUp' || e.key === 'w') {
        setControlState(prev => ({ ...prev, jump: false }));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Game loop
  useEffect(() => {
    if (gameOver || won || levels.length === 0) return;
    const level = levels[currentLevel];
    if (!level) return;

    const gameLoop = () => {
      const state = gameStateRef.current;
      
      // Horizontal movement
      if (controlState.left) {
        state.velocityX = -MOVE_SPEED;
      } else if (controlState.right) {
        state.velocityX = MOVE_SPEED;
      } else {
        state.velocityX = 0;
      }

      // Apply gravity
      state.velocityY += GRAVITY;

      // Calculate new position
      let newX = state.playerX + state.velocityX;
      let newY = state.playerY + state.velocityY;

      // Check collisions with platforms
      let onGround = false;
      level.platforms.forEach(platform => {
        const playerLeft = newX - PLAYER_WIDTH / 2;
        const playerRight = newX + PLAYER_WIDTH / 2;
        const playerTop = newY - PLAYER_HEIGHT / 2;
        const playerBottom = newY + PLAYER_HEIGHT / 2;

        const platLeft = platform.x - platform.width / 2;
        const platRight = platform.x + platform.width / 2;
        const platTop = platform.y - platform.height / 2;
        const platBottom = platform.y + platform.height / 2;

        if (playerRight > platLeft && playerLeft < platRight) {
          // Landing on top
          if (state.playerY + PLAYER_HEIGHT / 2 <= platTop && playerBottom >= platTop && state.velocityY > 0) {
            newY = platTop - PLAYER_HEIGHT / 2;
            state.velocityY = 0;
            onGround = true;
          }
          // Hitting from bottom
          else if (state.playerY - PLAYER_HEIGHT / 2 >= platBottom && playerTop <= platBottom && state.velocityY < 0) {
            newY = platBottom + PLAYER_HEIGHT / 2;
            state.velocityY = 0;
          }
        }
      });

      state.isOnGround = onGround;

      // Handle jump
      if (controlState.jump && onGround) {
        state.velocityY = JUMP_FORCE;
      }

      // Check coin collection (increased radius for better gameplay)
      level.coins.forEach((coin, index) => {
        if (!collectedCoinsRef.current.has(index)) {
          const dist = Math.sqrt(Math.pow(newX - coin.x, 2) + Math.pow(newY - coin.y, 2));
          if (dist < 40) {
            collectedCoinsRef.current.add(index);
            setCollectedCoins(new Set(collectedCoinsRef.current));
            setScore(s => s + 10);
          }
        }
      });

      // Check boundaries
      if (newX < PLAYER_WIDTH / 2) newX = PLAYER_WIDTH / 2;
      if (newX > screenSize.width - PLAYER_WIDTH / 2) newX = screenSize.width - PLAYER_WIDTH / 2;

      // Check if player fell off
      if (newY > screenSize.height + 50) {
        setGameOver(true);
        return;
      }

      // Update state
      state.playerX = newX;
      state.playerY = newY;

      setRenderState({ x: newX, y: newY });
    };

    gameLoopRef.current = setInterval(gameLoop, 1000 / 60);

    return () => {
      if (gameLoopRef.current) {
        clearInterval(gameLoopRef.current);
      }
    };
  }, [gameOver, won, currentLevel, levels, controlState, screenSize]);

  // Check win condition
  useEffect(() => {
    if (levels.length === 0) return;
    const level = levels[currentLevel];
    if (!level) return;
    
    if (collectedCoins.size >= level.coins.length && collectedCoins.size > 0) {
      if (currentLevel < levels.length - 1) {
        setTimeout(() => {
          setCurrentLevel(prev => prev + 1);
        }, 1000);
      } else {
        setWon(true);
      }
    }
  }, [collectedCoins.size, currentLevel, levels]);

  const resetGame = () => {
    if (levels.length === 0) return;
    setScore(0);
    setCurrentLevel(startLevel);
    setCollectedCoins(new Set());
    collectedCoinsRef.current = new Set();
    setGameOver(false);
    setWon(false);
    const level = levels[startLevel];
    if (level) {
      gameStateRef.current = {
        playerX: level.playerStart.x,
        playerY: level.playerStart.y,
        velocityX: 0,
        velocityY: 0,
        isOnGround: false,
      };
      setRenderState({ x: level.playerStart.x, y: level.playerStart.y });
    }
    setControlState({ left: false, right: false, jump: false });
  };

  if (levels.length === 0) return <div>Loading...</div>;
  const level = levels[currentLevel];
  if (!level) return <div>Loading...</div>;

  return (
    <div 
      ref={gameContainerRef}
      data-testid="game-screen"
      style={{
        width: screenSize.width,
        height: screenSize.height,
        backgroundColor: '#87CEEB',
        position: 'relative',
        overflow: 'hidden',
        margin: '0 auto',
        borderRadius: 8,
        boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
      }}
    >
      {/* HUD */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-around',
        padding: 16,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
      }}>
        <span data-testid="level-display" style={{ color: '#fff', fontSize: 16, fontWeight: 'bold' }}>
          Level: {currentLevel + 1}
        </span>
        <span data-testid="score-display" style={{ color: '#fff', fontSize: 16, fontWeight: 'bold' }}>
          Score: {score}
        </span>
        <span data-testid="coins-display" style={{ color: '#fff', fontSize: 16, fontWeight: 'bold' }}>
          Coins: {collectedCoins.size}/{level.coins.length}
        </span>
      </div>

      {/* Game Area */}
      {!gameOver && !won && (
        <>
          {level.platforms.map((platform, index) => (
            <Platform key={index} {...platform} />
          ))}
          {level.coins.map((coin, index) => (
            !collectedCoins.has(index) && <Coin key={index} {...coin} />
          ))}
          <Player x={renderState.x} y={renderState.y} />
          <Controls onControlChange={setControlState} />
        </>
      )}

      {/* Game Over / Win Modal */}
      {(gameOver || won) && (
        <div style={{
          position: 'absolute',
          inset: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 200,
        }}>
          <div style={{
            backgroundColor: '#fff',
            borderRadius: 16,
            padding: 32,
            textAlign: 'center',
            minWidth: 280,
            border: '4px solid #333',
          }}>
            <h2 data-testid="game-result" style={{ fontSize: 32, fontWeight: 'bold', color: '#333', marginBottom: 16 }}>
              {won ? '🎉 YOU WON!' : '💀 GAME OVER'}
            </h2>
            <p style={{ fontSize: 20, color: '#666', marginBottom: 24 }}>
              Final Score: {score}
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <button
                data-testid="retry-btn"
                onClick={resetGame}
                style={{
                  backgroundColor: '#4CAF50',
                  color: '#fff',
                  padding: '12px 24px',
                  borderRadius: 8,
                  border: '3px solid #2E7D32',
                  fontSize: 18,
                  fontWeight: 'bold',
                  cursor: 'pointer',
                }}
              >
                RETRY
              </button>
              <button
                data-testid="menu-btn"
                onClick={() => navigate('/')}
                style={{
                  backgroundColor: '#666',
                  color: '#fff',
                  padding: '12px 24px',
                  borderRadius: 8,
                  border: '3px solid #444',
                  fontSize: 18,
                  fontWeight: 'bold',
                  cursor: 'pointer',
                }}
              >
                MENU
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Instructions */}
      <div style={{
        position: 'absolute',
        bottom: 160,
        left: 0,
        right: 0,
        textAlign: 'center',
        color: '#fff',
        fontSize: 12,
        opacity: 0.7,
        textShadow: '1px 1px 2px rgba(0,0,0,0.5)',
      }}>
        Use Arrow Keys / WASD to move, Space to jump
      </div>
    </div>
  );
};

// Main Menu Component
const MainMenu = () => {
  const navigate = useNavigate();

  return (
    <div 
      data-testid="main-menu"
      style={{
        minHeight: '100vh',
        backgroundColor: '#87CEEB',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
      }}
    >
      <h1 style={{
        fontSize: 64,
        fontWeight: 'bold',
        color: '#fff',
        textShadow: '4px 4px 0 #000',
        letterSpacing: 4,
        marginBottom: 0,
      }}>
        PIXEL
      </h1>
      <h1 style={{
        fontSize: 64,
        fontWeight: 'bold',
        color: '#fff',
        textShadow: '4px 4px 0 #000',
        letterSpacing: 4,
        marginTop: 0,
      }}>
        PLATFORMER
      </h1>
      
      <div style={{ marginTop: 60, display: 'flex', flexDirection: 'column', gap: 20, width: '100%', maxWidth: 300 }}>
        <button
          data-testid="start-game-btn"
          onClick={() => navigate('/game')}
          style={{
            backgroundColor: '#4CAF50',
            color: '#fff',
            padding: '16px 32px',
            borderRadius: 8,
            border: '4px solid #2E7D32',
            fontSize: 24,
            fontWeight: 'bold',
            cursor: 'pointer',
            textShadow: '2px 2px 0 #000',
            transition: 'transform 0.1s',
          }}
          onMouseDown={(e) => e.currentTarget.style.transform = 'scale(0.95)'}
          onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
        >
          START GAME
        </button>
        
        <button
          data-testid="levels-btn"
          onClick={() => navigate('/levels')}
          style={{
            backgroundColor: '#2196F3',
            color: '#fff',
            padding: '16px 32px',
            borderRadius: 8,
            border: '4px solid #1565C0',
            fontSize: 24,
            fontWeight: 'bold',
            cursor: 'pointer',
            textShadow: '2px 2px 0 #000',
            transition: 'transform 0.1s',
          }}
          onMouseDown={(e) => e.currentTarget.style.transform = 'scale(0.95)'}
          onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
        >
          LEVELS
        </button>
      </div>
      
      <p style={{
        position: 'absolute',
        bottom: 20,
        fontSize: 12,
        color: '#fff',
        opacity: 0.7,
      }}>
        Made with Kenney Assets
      </p>
    </div>
  );
};

// Levels Component
const Levels = () => {
  const navigate = useNavigate();
  const [screenSize, setScreenSize] = useState({ width: 800, height: 600 });
  const [levels, setLevels] = useState([]);

  useEffect(() => {
    const width = Math.min(window.innerWidth, 800);
    const height = Math.min(window.innerHeight - 50, 600);
    setScreenSize({ width, height });
    setLevels(createLevels(width, height));
  }, []);

  return (
    <div 
      data-testid="levels-screen"
      style={{
        minHeight: '100vh',
        backgroundColor: '#87CEEB',
        padding: 20,
      }}
    >
      <div style={{
        padding: 20,
        backgroundColor: 'rgba(0, 0, 0, 0.3)',
        borderRadius: 8,
        marginBottom: 20,
      }}>
        <button
          data-testid="back-btn"
          onClick={() => navigate('/')}
          style={{
            background: 'none',
            border: 'none',
            color: '#fff',
            fontSize: 16,
            fontWeight: 'bold',
            cursor: 'pointer',
            marginBottom: 10,
          }}
        >
          ← BACK
        </button>
        <h2 style={{ fontSize: 28, fontWeight: 'bold', color: '#fff', textAlign: 'center', margin: 0 }}>
          SELECT LEVEL
        </h2>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 500, margin: '0 auto' }}>
        {levels.map((level, index) => (
          <div
            key={index}
            data-testid={`level-card-${index}`}
            onClick={() => navigate(`/game?level=${index}`)}
            style={{
              backgroundColor: '#fff',
              borderRadius: 12,
              padding: 20,
              display: 'flex',
              alignItems: 'center',
              border: '3px solid #333',
              cursor: 'pointer',
              transition: 'transform 0.1s',
            }}
            onMouseDown={(e) => e.currentTarget.style.transform = 'scale(0.98)'}
            onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
          >
            <span style={{ fontSize: 48, fontWeight: 'bold', color: '#4CAF50', marginRight: 20, width: 60 }}>
              {index + 1}
            </span>
            <div>
              <h3 style={{ fontSize: 20, fontWeight: 'bold', color: '#333', margin: 0 }}>
                {level.name}
              </h3>
              <p style={{ fontSize: 14, color: '#666', margin: 0 }}>
                Coins: {level.coins.length}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// Main App
function App() {
  return (
    <div className="App" style={{ backgroundColor: '#87CEEB', minHeight: '100vh' }}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<MainMenu />} />
          <Route path="/game" element={<Game />} />
          <Route path="/levels" element={<Levels />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
